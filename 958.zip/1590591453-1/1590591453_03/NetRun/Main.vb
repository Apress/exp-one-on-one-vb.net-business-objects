Imports System.Reflection
Imports System.Security
Imports System.Security.Policy
Imports System.Security.Permissions

Module Main

  Private mAppURL As String
  Private mAppDir As String
  Private mAppName As String

  Private mGroupExisted As Boolean

  Public Sub Main()

    ' before we do anything, invoke the workaround
    ' for the serialization bug
    SerializationWorkaround()

    ' get and parse the URL for the app we are
    ' launching
    mAppURL = Microsoft.VisualBasic.Command
    mAppDir = GetAppDirectory(mAppURL)
    mAppName = GetAppName(mAppURL)

    ' now move on to launch the app based on the 
    ' URL provided by the user
    Try
      SetSecurity()
      RunAppliation()
      RemoveSecurity()

    Catch ex As Exception
      Dim sb As New System.Text.StringBuilder
      sb.Append("NetRun was unable to launch the application")
      sb.Append(vbCrLf)
      sb.Append(mAppURL)
      sb.Append(vbCrLf)
      sb.Append(vbCrLf)
      sb.Append(ex.ToString)
      MsgBox(sb.ToString, MsgBoxStyle.Exclamation)
    End Try

  End Sub

#Region " Serialization bug workaround "

  Private Sub SerializationWorkaround()

    ' hook up the AssemblyResolve
    ' event so deep serialization works properly
    ' this is a workaround for a bug in the .NET runtime
    Dim currentDomain As AppDomain = AppDomain.CurrentDomain

    AddHandler currentDomain.AssemblyResolve, _
      AddressOf ResolveEventHandler

  End Sub

  Private Function ResolveEventHandler(ByVal sender As Object, ByVal args As ResolveEventArgs) As [Assembly]

    ' get a list of all the assemblies loaded in our appdomain
    Dim list() As [Assembly] = AppDomain.CurrentDomain.GetAssemblies()

    ' search the list to find the assemby that was not found automatically
    ' and return the assembly from the list
    Dim asm As [Assembly]

    For Each asm In list
      If asm.FullName = args.Name Then
        Return asm
      End If
    Next

  End Function

#End Region

#Region " RunApplication "

  Public Sub RunAppliation()

    Dim asm As [Assembly]

    ' load the assembly into our AppDomain
    asm = [Assembly].LoadFrom(mAppURL)

    ' record the URL of the remote assembly into a global
    ' AppDomain data variable for use by CSLA.Configuration
    ' so it knows where to get the .remoteconfig file
    AppDomain.CurrentDomain.SetData("RemoteEXE", mAppURL)

    ' run the program by invoking its entry point
    asm.EntryPoint.Invoke(asm.EntryPoint, Nothing)

    ' now that the program is done, remove the URL from the
    ' AppDomain variable
    AppDomain.CurrentDomain.SetData("RemoteEXE", Nothing)

  End Sub

#End Region

#Region " SetSecurity to FullTrust "

  Public Sub SetSecurity()

    Dim ph As System.Collections.IEnumerator
    Dim pl As System.Security.Policy.PolicyLevel
    Dim found As Boolean

    ' retrieve the security policy hierarchy
    ph = SecurityManager.PolicyHierarchy

    ' loop through to find the Machine level sub-tree
    Do While ph.MoveNext
      pl = CType(ph.Current, PolicyLevel)
      If pl.Label = "Machine" Then
        found = True
        Exit Do
      End If
    Loop

    If found Then
      ' see if the codegroup for this app already exists
      ' as a machine-level entry
      Dim cg As CodeGroup
      For Each cg In pl.RootCodeGroup.Children
        If cg.Name = mAppName Then
          ' codegroup already exists
          ' we assume it is set to a valid
          ' permission level
          mGroupExisted = True
          Exit Sub
        End If
      Next

      ' the codegroup doesn't already exist, so 
      ' we'll add a url group with FullTrust
      mGroupExisted = False
      Dim ucg As UnionCodeGroup = _
        New UnionCodeGroup(New UrlMembershipCondition(mAppDir & "/*"), _
        New PolicyStatement(New NamedPermissionSet("FullTrust")))
      ucg.Description = "Temporary entry for " & mAppURL
      ucg.Name = mAppName
      pl.RootCodeGroup.AddChild(ucg)
      SecurityManager.SavePolicy()
    End If

  End Sub

#End Region

#Region " RemoveSecurity "

  Public Sub RemoveSecurity()

    ' if the group existed before NetRun was used
    ' we want to leave the group intact, so we
    ' can just exit
    If mGroupExisted Then Exit Sub

    ' on the other hand, if the group didn't already
    ' exist then we need to remove it now that
    ' the business application is closed
    Dim ph As System.Collections.IEnumerator
    Dim pl As System.Security.Policy.PolicyLevel
    Dim found As Boolean

    ' retrieve the security policy hierarchy
    ph = SecurityManager.PolicyHierarchy

    ' loop through to find the Machine level sub-tree
    Do While ph.MoveNext
      pl = CType(ph.Current, PolicyLevel)
      If pl.Label = "Machine" Then
        found = True
        Exit Do
      End If
    Loop

    If found Then
      ' see if the codegroup for this app exists
      ' as a machine-level entry
      Dim cg As CodeGroup
      For Each cg In pl.RootCodeGroup.Children
        If cg.Name = mAppName Then
          ' codegroup exits - remove it
          pl.RootCodeGroup.RemoveChild(cg)
          SecurityManager.SavePolicy()
          Exit For
        End If
      Next
    End If

  End Sub

#End Region

#Region " URL parsing functions "

  Private Function GetAppDirectory(ByVal AppURL As String) As String

    ' get the path without prog name
    Dim appURI As New System.Uri(AppURL)
    Dim appPath As String = appURI.GetLeftPart(UriPartial.Path)
    Dim pos As Integer

    For pos = Len(appPath) To 1 Step -1
      If Mid(appPath, pos, 1) = "/" OrElse Mid(appPath, pos, 1) = "\" Then
        Return Left(appPath, pos - 1)
      End If
    Next
    Return ""

  End Function

  Private Function GetAppName(ByVal AppURL As String) As String

    ' get the prog name without path
    Dim appURI As New System.Uri(AppURL)
    Dim appPath As String = appURI.GetLeftPart(UriPartial.Path)
    Dim pos As Integer

    For pos = Len(appPath) To 1 Step -1
      If Mid(appPath, pos, 1) = "/" OrElse Mid(appPath, pos, 1) = "\" Then
        Return Mid(appPath, pos + 1)
      End If
    Next
    Return ""

  End Function

#End Region

End Module
