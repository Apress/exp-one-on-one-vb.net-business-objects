Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.ComponentModel
Imports System.Configuration

<Serializable()> _
Public MustInherit Class BusinessBase
  Inherits Core.UndoableBase

  Implements IEditableObject
  Implements ICloneable

#Region " IsNew, IsDeleted, IsDirty "

  ' keep track of whether we are new, deleted or dirty
  Private mIsNew As Boolean = True
  Private mIsDeleted As Boolean = False
  Private mIsDirty As Boolean = True

  Public ReadOnly Property IsNew() As Boolean
    Get
      Return mIsNew
    End Get
  End Property

  Public ReadOnly Property IsDeleted() As Boolean
    Get
      Return mIsDeleted
    End Get
  End Property

  Public Overridable ReadOnly Property IsDirty() As Boolean
    Get
      Return mIsDirty
    End Get
  End Property

  Protected Sub MarkNew()
    mIsNew = True
    mIsDeleted = False
    MarkDirty()
  End Sub

  Protected Sub MarkOld()
    mIsNew = False
    MarkClean()
  End Sub

  Protected Sub MarkDeleted()
    mIsDeleted = True
    MarkDirty()
  End Sub

  Protected Sub MarkDirty()
    mIsDirty = True
    OnIsDirtyChanged()
  End Sub

  Private Sub MarkClean()
    mIsDirty = False
    OnIsDirtyChanged()
  End Sub

#End Region

#Region " Begin/Cancel/ApplyEdit "

  <NotUndoable()> _
  Private mBindingEdit As Boolean = False

  ' allow data binding to start a nested edit on the object
  Private Sub BindingBeginEdit() Implements IEditableObject.BeginEdit
    If Not mBindingEdit Then
      BeginEdit()
    End If
  End Sub

  ' allow the UI to start a nested edit on the object
  Public Sub BeginEdit()
    mBindingEdit = True
    CopyState()
  End Sub

  ' allow the UI to cancel a nested edit on the object
  Public Sub CancelEdit() Implements IEditableObject.CancelEdit
    mBindingEdit = False
    UndoChanges()
  End Sub

  ' allow the UI to apply a nested edit on the object
  Public Sub ApplyEdit() Implements IEditableObject.EndEdit
    mBindingEdit = False
    AcceptChanges()
  End Sub

#End Region

#Region " IsChild "

  <NotUndoable()> _
  Private mIsChild As Boolean = False

  Friend ReadOnly Property IsChild() As Boolean
    Get
      Return mIsChild
    End Get
  End Property

  Protected Sub MarkAsChild()
    mIsChild = True
  End Sub

#End Region

#Region " Delete "

  ' allow the UI to mark the object for deletion
  ' if this is a root object
  Public Sub Delete()
    If Me.IsChild Then
      Throw New NotSupportedException("Can not directly mark a child object for deletion - use its parent collection")
    End If

    MarkDeleted()

  End Sub

  ' allow the parent object to delete us
  ' (Friend scope)
  Friend Sub DeleteChild()
    If Not Me.IsChild Then
      Throw New NotSupportedException("Invalid for root objects - use Delete instead")
    End If

    MarkDeleted()

  End Sub

#End Region

#Region " Edit Level Tracking (child only) "

  ' we need to keep track of the edit
  ' level when we were added so if the user
  ' cancels below that level we can be destroyed
  Private mEditLevelAdded As Integer

  ' allow the collection object to use the
  ' edit level as needed (Friend scope)
  Friend Property EditLevelAdded() As Integer
    Get
      Return mEditLevelAdded
    End Get
    Set(ByVal Value As Integer)
      mEditLevelAdded = Value
    End Set
  End Property

#End Region

#Region " Clone "

  ' all business objects _must_ be serializable
  ' and thus can be cloned - this just clinches
  ' the deal
  Public Function Clone() As Object _
    Implements ICloneable.Clone

    Dim buffer As New MemoryStream
    Dim formatter As New BinaryFormatter

    formatter.Serialize(buffer, Me)
    buffer.Position = 0
    Return formatter.Deserialize(buffer)
  End Function

#End Region

#Region " BrokenRules, IsValid "

  ' keep a list of broken rules
  Private mBrokenRules As New BrokenRules

  Public Overridable ReadOnly Property IsValid() As Boolean
    Get
      Return mBrokenRules.IsValid
    End Get
  End Property

  Public Function GetBrokenRulesCollection() As BrokenRules.RulesCollection
    Return mBrokenRules.GetBrokenRules
  End Function

  Public Function GetBrokenRulesString() As String
    Return mBrokenRules.ToString
  End Function

  ' support broken rules tracking
  Protected ReadOnly Property BrokenRules() As BrokenRules
    Get
      Return mBrokenRules
    End Get
  End Property

#End Region

#Region " Data Access "

  ' add/save object
  Public Overridable Function Save() As BusinessBase
    If Me.IsChild Then
      Throw New NotSupportedException("Can not directly save a child object")
    End If

    If EditLevel > 0 Then
      Throw New Exception("Object is still being edited and can not be saved")
    End If

    If Not IsValid Then
      Throw New Exception("Object is not valid and can not be saved")
    End If

    If IsDirty Then
      Return CType(DataPortal.Update(Me), BusinessBase)
    Else
      Return Me
    End If

  End Function

  Protected Overridable Sub DataPortal_Create(ByVal Criteria As Object)
    Throw New NotSupportedException("Invalid operation - create not allowed")
  End Sub

  Protected Overridable Sub DataPortal_Fetch(ByVal Criteria As Object)
    Throw New NotSupportedException("Invalid operation - fetch not allowed")
  End Sub

  Protected Overridable Sub DataPortal_Update()
    Throw New NotSupportedException("Invalid operation - update not allowed")
  End Sub

  Protected Overridable Sub DataPortal_Delete(ByVal Criteria As Object)
    Throw New NotSupportedException("Invalid operation - delete not allowed")
  End Sub

  Protected Function DB(ByVal DatabaseName As String) As String
    Return ConfigurationSettings.AppSettings("DB:" & DatabaseName)
  End Function

#End Region

End Class
