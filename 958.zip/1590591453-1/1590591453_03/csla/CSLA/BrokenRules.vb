<Serializable()> _
Public Class BrokenRules

#Region " Rule structure "

  <Serializable()> _
  Public Structure Rule
    Private mRule As String
    Private mDescription As String

    Friend Sub New(ByVal Rule As String, ByVal Description As String)
      mRule = Rule
      mDescription = Description
    End Sub

    Public Property Rule() As String
      Get
        Return mRule
      End Get
      Set(ByVal Value As String)
        ' the property must be read-write for Web Forms data binding
        ' to work, but we really don't want to allow the value to be
        ' changed dynamically so we ignore any attempt to set it
      End Set
    End Property

    Public Property Description() As String
      Get
        Return mDescription
      End Get
      Set(ByVal Value As String)
        ' the property must be read-write for Web Forms data binding
        ' to work, but we really don't want to allow the value to be
        ' changed dynamically so we ignore any attempt to set it
      End Set
    End Property
  End Structure

#End Region

#Region " RulesCollection "

  <Serializable()> _
  Public Class RulesCollection
    Inherits CSLA.Core.BindableCollectionBase

    Private mLegal As Boolean = False

    Default Public ReadOnly Property Item(ByVal Index As Integer) As Rule
      Get
        Return CType(list.Item(Index), Rule)
      End Get
    End Property

    Friend Sub New()
      AllowEdit = False
      AllowRemove = False
      AllowNew = False
    End Sub

    Friend Sub Add(ByVal Rule As String, ByVal Description As String)
      Remove(Rule)
      mLegal = True
      list.Add(New Rule(Rule, Description))
      mLegal = False
    End Sub

    Friend Sub Remove(ByVal Rule As String)
      Dim index As Integer

      ' we loop through using a numeric counter because
      ' the base class Remove requires a numberic index
      mLegal = True
      For index = 0 To list.Count - 1
        If CType(list.Item(index), Rule).Rule = Rule Then
          list.Remove(list.Item(index))
          Exit For
        End If
      Next
      mLegal = False
    End Sub

    Friend Function Contains(ByVal Rule As String) As Boolean
      Dim index As Integer

      For index = 0 To list.Count - 1
        If CType(list.Item(index), Rule).Rule = Rule Then
          Return True
        End If
      Next
      Return False
    End Function

    Protected Overrides Sub OnClear()
      If Not mLegal Then
        Throw New NotSupportedException("Clear is an invalid operation")
      End If
    End Sub

    Protected Overrides Sub OnInsert(ByVal index As Integer, ByVal value As Object)
      If Not mLegal Then
        Throw New NotSupportedException("Insert is an invalid operation")
      End If
    End Sub

    Protected Overrides Sub OnRemove(ByVal index As Integer, ByVal value As Object)
      If Not mLegal Then
        Throw New NotSupportedException("Remove is an invalid operation")
      End If
    End Sub

    Protected Overrides Sub OnSet(ByVal index As Integer, _
        ByVal oldValue As Object, ByVal newValue As Object)
      If Not mLegal Then
        Throw New NotSupportedException("Changing an element is an invalid operation")
      End If
    End Sub
  End Class

#End Region

  Private mRules As New RulesCollection

  Public Sub Assert(ByVal Rule As String, ByVal Description As String, ByVal IsBroken As Boolean)
    If IsBroken Then
      mRules.Add(Rule, Description)
    Else
      mRules.Remove(Rule)
    End If
  End Sub

  Public ReadOnly Property IsValid() As Boolean
    Get
      Return mRules.Count = 0
    End Get
  End Property

  Public Function IsBroken(ByVal Rule As String) As Boolean
    Return mRules.Contains(Rule)
  End Function

  Public Function GetBrokenRules() As RulesCollection
    Return mRules
  End Function

  Public Overrides Function ToString() As String
    Dim obj As New System.Text.StringBuilder
    Dim item As Rule

    For Each item In mRules
      obj.Append(item.Description)
      obj.Append(vbCrLf)
    Next
    Return obj.ToString
  End Function

End Class
