Imports System.Xml
Imports System.Collections.Specialized

Public Class ConfigurationSettings
  Private Shared Cache As NameValueCollection

  Public Shared Function AppSettings() As NameValueCollection
    Dim URL As String = CStr(AppDomain.CurrentDomain.GetData("RemoteEXE"))
    If Len(URL) > 0 Then
      ' we are running remote exe and need to load config manually
      If Cache Is Nothing Then
        Try
          Cache = LoadSettings(URL & ".remoteconfig")
        Catch
          Cache = New NameValueCollection()
        End Try
      End If
      Return Cache
    Else
      ' we are running normally and can just use regular config
      Return System.Configuration.ConfigurationSettings.AppSettings
    End If
  End Function

  Private Shared Function LoadSettings(ByVal Config As String) As NameValueCollection
    Dim col As New NameValueCollection()
    Dim xml As New XmlDocument()

    xml.Load(Config)
    Dim root As XmlElement = _
      CType(xml.GetElementsByTagName("configuration").Item(0), XmlElement)
    Dim settings As XmlElement = _
      CType(root.GetElementsByTagName("appSettings").Item(0), XmlElement)
    Dim node As XmlNode
    Dim cmd As XmlElement

    For Each node In settings.ChildNodes
      If node.NodeType = XmlNodeType.Element Then
        cmd = CType(node, XmlElement)
        Select Case cmd.Name
          Case "add"
            col.Add(cmd.GetAttribute("key"), cmd.GetAttribute("value"))

          Case "clear"
            col.Clear()

        End Select
      End If
    Next

    Return col
  End Function

  Private Sub New()
    ' prevent instantiation of the class
  End Sub
End Class
