Imports System.ComponentModel
Imports System.Configuration.Install
Imports System.ServiceProcess

<RunInstaller(True)> Public Class BatchQueueInstaller
    Inherits System.Configuration.Install.Installer

#Region " Component Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Installer overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

  Private mServiceInstaller As New ServiceInstaller
  Private mProcessInstaller As New ServiceProcessInstaller

  Private Sub InitInstaller()
    mProcessInstaller.Account = ServiceAccount.LocalSystem
    mServiceInstaller.StartType = ServiceStartMode.Automatic
    mServiceInstaller.ServiceName = "CSLABatchQueue"
    Installers.Add(mServiceInstaller)
    Installers.Add(mProcessInstaller)
  End Sub

  Private Sub Installer_BeforeInstall(ByVal sender As Object, _
    ByVal e As System.Configuration.Install.InstallEventArgs) _
    Handles MyBase.BeforeInstall

    InitInstaller()

  End Sub

  Private Sub Installer_BeforeRollback(ByVal sender As Object, _
      ByVal e As System.Configuration.Install.InstallEventArgs) _
      Handles MyBase.BeforeRollback

    InitInstaller()

  End Sub

  Private Sub Installer_BeforeUninstall(ByVal sender As Object, _
      ByVal e As System.Configuration.Install.InstallEventArgs) _
      Handles MyBase.BeforeUninstall

    InitInstaller()

  End Sub

End Class
