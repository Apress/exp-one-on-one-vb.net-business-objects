Imports CSLA.BatchQueue.Server

Module Module1

  Sub Main()

    Console.WriteLine("server on thread {0}", AppDomain.GetCurrentThreadId)

    Console.WriteLine("starting...")
    BatchQueueService.Start()
    Console.WriteLine("started")

    Console.WriteLine("Press ENTER to end")
    Console.ReadLine()

    Console.WriteLine("stopping...")
    BatchQueueService.Stop()
    Console.WriteLine("stopped")

  End Sub

End Module
