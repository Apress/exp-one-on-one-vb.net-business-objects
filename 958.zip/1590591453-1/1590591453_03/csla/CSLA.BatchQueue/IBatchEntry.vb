Public Interface IBatchEntry
  Sub Execute(ByVal State As Object)
End Interface
