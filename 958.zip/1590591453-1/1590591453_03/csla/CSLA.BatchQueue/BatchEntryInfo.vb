Imports System.Environment

Public Enum BatchEntryStatus
  Pending
  Holding
  Active
End Enum

<Serializable()> _
Public Class BatchEntryInfo

  Private mID As Guid = Guid.NewGuid
  Private mSubmitted As Date = Now
  Private mUser As String = System.Environment.UserName
  Private mMachine As String = System.Environment.MachineName
  Private mPriority As Messaging.MessagePriority = Messaging.MessagePriority.Normal
  Private mMsgID As String
  Private mHoldUntil As Date = Date.MinValue
  Private mStatus As BatchEntryStatus = BatchEntryStatus.Pending

  Public ReadOnly Property ID() As Guid
    Get
      Return mID
    End Get
  End Property

  Public ReadOnly Property Submitted() As Date
    Get
      Return mSubmitted
    End Get
  End Property

  Public ReadOnly Property User() As String
    Get
      Return mUser
    End Get
  End Property

  Public ReadOnly Property Machine() As String
    Get
      Return mMachine
    End Get
  End Property

  Public Property Priority() As Messaging.MessagePriority
    Get
      Return mPriority
    End Get
    Set(ByVal Value As Messaging.MessagePriority)
      mPriority = Value
    End Set
  End Property

  Public ReadOnly Property MessageID() As String
    Get
      Return mMsgID
    End Get
  End Property

  Friend Sub SetMessageID(ByVal ID As String)
    mMsgID = ID
  End Sub

  Public Property HoldUntil() As Date
    Get
      Return mHoldUntil
    End Get
    Set(ByVal Value As Date)
      mHoldUntil = Value
    End Set
  End Property

  Public ReadOnly Property Status() As BatchEntryStatus
    Get
      If mHoldUntil > Now AndAlso mStatus = BatchEntryStatus.Pending Then
        Return BatchEntryStatus.Holding

      Else
        Return mStatus
      End If
    End Get
  End Property

  Friend Sub SetStatus(ByVal Status As BatchEntryStatus)

    mStatus = Status

  End Sub

#Region " System.Object overrides "

  Public Overrides Function ToString() As String

    Return mUser & "@" & mMachine & ":" & mID.ToString

  End Function

  Public Overloads Function Equals(ByVal Info As BatchEntryInfo) As Boolean

    Return mID.Equals(Info.ID)

  End Function

  Public Overrides Function GetHashCode() As Integer

    Return mID.GetHashCode

  End Function

#End Region

End Class
