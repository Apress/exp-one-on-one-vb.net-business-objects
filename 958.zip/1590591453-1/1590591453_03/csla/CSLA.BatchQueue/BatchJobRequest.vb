<Serializable()> _
Public Class BatchJobRequest

  Implements IBatchEntry

  Private mAssembly As String = ""
  Private mType As String = ""

  Public Sub New(ByVal Type As String, ByVal [Assembly] As String)
    mAssembly = [Assembly]
    mType = Type
  End Sub

  Public Property Type() As String
    Get
      Return mType
    End Get
    Set(ByVal Value As String)
      mType = Value
    End Set
  End Property

  Public Property [Assembly]() As String
    Get
      Return mAssembly
    End Get
    Set(ByVal Value As String)
      mAssembly = Value
    End Set
  End Property

  ' this method runs on the server - it is called
  ' by BatchEntry, which is called by Server.BatchQueueService
  Public Sub Execute(ByVal State As Object) _
      Implements IBatchEntry.Execute

    ' create an instance of the specified object
    Dim job As IBatchEntry
    job = CType(AppDomain.CurrentDomain.CreateInstanceAndUnwrap(mAssembly, mType), IBatchEntry)

    ' execute the job
    job.Execute(State)

  End Sub

#Region " System.Object overrides "

  Public Overrides Function ToString() As String

    Return "BatchJobRequest: " & mType & "," & mAssembly

  End Function

#End Region

End Class
